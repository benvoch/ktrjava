package doanJAVA.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import doanJAVA.model.Cart;
import doanJAVA.model.Product;
import doanJAVA.service.ProductService;
import doanJAVA.service.ShoppingCartService;

@Controller
@RequestMapping("shoppingcart")
public class ShoppingCartController {

	@Autowired
	ProductService productService;
	@Autowired
	private ShoppingCartService shoppingCartService;

	@GetMapping("view")
	public String viewCart(Model model) {
		model.addAttribute("all_items_in_shoppingcart", shoppingCartService.getAllItems());
		model.addAttribute("total_amount", shoppingCartService.getAmount());
		return "ShoppingCart/view_shoppingcart";
	}

	@GetMapping("add/{id}")
	public String addItem(@PathVariable("id") Integer id) {
		Product product = productService.getProductById(id);
		if (product != null) {
			Cart item = new Cart();
			item.setProduct(product);
		}
		return "redirect:/ShoppingCart/view";
	}

	@GetMapping("clear")
	public String clearCart() {
		shoppingCartService.clear();
		return "redirect:/ShoppingCart/view";
	}

	@GetMapping("remove/{id}")
	public String removeItem(@PathVariable("id") Integer id) {
		shoppingCartService.remove(id);
		return "redirect:/ShoppingCart/view";
	}

	@PostMapping("update")
	public String updateItem(@RequestParam("productId") Integer productId, @RequestParam("quantity") Integer quantity) {
		shoppingCartService.update(productId, quantity);
		return "redirect:/ShoppingCart/view";
	}
}
