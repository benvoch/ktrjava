package doanJAVA;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Bt1tuan4Application {

	public static void main(String[] args) {
		SpringApplication.run(Bt1tuan4Application.class, args);
	}

}
