package doanJAVA.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import doanJAVA.model.Role;
import doanJAVA.repository.RoleRepository;

@Service
public class RoleService {
	@Autowired
	RoleRepository rolerepo;
	public List<Role> GetAll()
	{
		return(List<Role>) rolerepo.findAll();
	}
}
