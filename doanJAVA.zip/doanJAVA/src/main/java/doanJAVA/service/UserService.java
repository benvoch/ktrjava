package doanJAVA.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import doanJAVA.model.User;
import doanJAVA.repository.UserRepository;

@Service
public class UserService {

	@Autowired 
	private UserRepository userrepo;
	
	public List<User> GetAll()
	{
		return(List<User>) userrepo.findAll();
	}
	public void add(User newUser)
	{
		userrepo.save(newUser);
	}
	public void delete(Long id)
	{
		userrepo.deleteById(id);
	}
	public User getById(Long Id) {
		// TODO Auto-generated method stub
		return userrepo.findById(Id).get();
	}
	public void edit(User editUser)
	{
		userrepo.save(editUser);
	}
	
}
