package doanJAVA.service;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Service;

import doanJAVA.model.Cart;
@Service
public class ShoppingCartService {

	Map<Integer, Cart> shoppingCart = new HashMap<>();

	
	public void add(Cart newItem) {
		Cart cartItem = shoppingCart.get(newItem.getProduct().getId());
		if (cartItem == null) {
			shoppingCart.put(newItem.getProduct().getId(), newItem);
		} else {
			cartItem.getProduct_count();
		}
	}

	
	public void remove(int id) {
		shoppingCart.remove(id);

	}

	
	public Cart update(int productID, int quantity) {
		Cart cartItem = shoppingCart.get(productID);
		cartItem.setProduct_count(quantity);
		return cartItem;
	}

	public void clear() {
		shoppingCart.clear();
	}

	
	public double getAmount() {
		return shoppingCart.values().stream()
				.mapToDouble(item -> item.getProduct_count() * item.getProduct().getPrice())
				.sum();
	}

	
	public int getCount() {
		return shoppingCart.values().size();
	}

	
	public Collection<Cart> getAllItems() {
		return shoppingCart.values();
	}

}
