package doanJAVA.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import doanJAVA.model.Role;
import doanJAVA.model.User;
import doanJAVA.service.RoleService;
import doanJAVA.service.UserService;



@Controller
@RequestMapping("users")
public class UserController {
	@Autowired 
	private UserService UserService;
	@Autowired
	private RoleService roleService;
	@GetMapping("")
	public String index(Model model)
	{
		model.addAttribute("listUser",UserService.GetAll());
		return "User/index";
	}
	@RequestMapping("/delete/{MaSV}")
	public String delete(@PathVariable(name = "MaSV") Long MaSV) {
		
		UserService.delete(MaSV);
		return "redirect:/";   
	}
	@GetMapping("/create")
	public String create(Model model)
	{
		User user= new User();
		List<Role> listRole = roleService.GetAll();
		model.addAttribute("newUser", user);
		model.addAttribute("listRole",listRole);
		return "User/create";
	}
	@PostMapping("/create")
	public String create( @ModelAttribute("newUser") User newUser)
	{
		UserService.add(newUser);
		return"redirect:/";
	}
	@GetMapping("/edit/{MaSV}")
	public String edit(@PathVariable(name = "MaSV") Long MaSV,Model model)
	{
		User editUser= UserService.getById(MaSV);
		if(editUser!=null)
		{
		model.addAttribute("SV", editUser);
		List<Role> listRole = roleService.GetAll();
		model.addAttribute("listkhoa",listRole);
		return "User/edit";
		}
		else 
			return "User/index"; 
	}
	@PostMapping("/edit")
	public String edit(@ModelAttribute("SV") User editUser)
	{
		UserService.edit(editUser);
		return "redirect:/"; 
	}
}