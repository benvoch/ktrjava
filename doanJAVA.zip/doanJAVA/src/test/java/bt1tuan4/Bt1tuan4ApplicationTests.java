package bt1tuan4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Bt1tuan4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
