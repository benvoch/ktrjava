package doanJAVA.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import doanJAVA.model.Cart;

public interface CartRepository extends JpaRepository<Cart, Integer> {

}
