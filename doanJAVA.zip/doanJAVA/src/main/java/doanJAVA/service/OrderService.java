package doanJAVA.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import doanJAVA.repository.OrderRepository;

@Service
public class OrderService {
	@Autowired
	OrderRepository oderRepo;
	
}
